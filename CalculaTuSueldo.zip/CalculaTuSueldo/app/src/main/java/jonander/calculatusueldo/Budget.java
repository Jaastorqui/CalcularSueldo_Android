/**
 * Created by Jon on 25/03/2018.
 */
package jonander.calculatusueldo;
public class Budget {
    double annual;
    double quotation;
    double contingencies;
    double unemployment;
    double fp;
    double taxes;
    double irpf;
    double monthly;
    double add_mouth;
    double extra;

    public double getExtra() {
        return extra;
    }

    public void setExtra(double extra) {
        this.extra = extra;
    }

    public double getAnnual() {
        return annual;
    }

    public void setAnnual(double annual) {
        this.annual = annual;
    }

    public double getQuotation() {
        return quotation;
    }

    public void setQuotation(double quotation) {
        this.quotation = quotation;
    }

    public double getContingencies() {
        return contingencies;
    }

    public void setContingencies(double contingencies) {
        this.contingencies = contingencies;
    }

    public double getUnemployment() {
        return unemployment;
    }

    public void setUnemployment(double unemployment) {
        this.unemployment = unemployment;
    }

    public double getFp() {
        return fp;
    }

    public void setFp(double fp) {
        this.fp = fp;
    }

    public double getTaxes() {
        return taxes;
    }

    public void setTaxes(double taxes) {
        this.taxes = taxes;
    }

    public double getIrpf() {
        return irpf;
    }

    public void setIrpf(double irpf) {
        this.irpf = irpf;
    }

    public double getMonthly() {
        return monthly;
    }

    public void setMonthly(double monthly) {
        this.monthly = monthly;
    }

    public double getAdd_mouth() {
        return add_mouth;
    }

    public void setAdd_mouth(double add_mouth) {
        this.add_mouth = add_mouth;
    }
}
